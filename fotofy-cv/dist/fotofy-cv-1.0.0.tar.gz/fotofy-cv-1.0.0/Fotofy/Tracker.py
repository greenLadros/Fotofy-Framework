#ivri korem 2020
"""
The Tracker class in the Fotofy Framework
"""

#import
import numpy as np
import cv2 as cv

class Tracker():
    pass
