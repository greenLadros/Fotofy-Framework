# __init__.py to store package vars
# like Fotofy.__version__

# Version of the Fotofy Framwork
__version__ = "1.0.0"