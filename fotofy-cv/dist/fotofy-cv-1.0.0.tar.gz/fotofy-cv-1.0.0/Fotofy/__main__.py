## here write the script for the
## python -m Fotofy command