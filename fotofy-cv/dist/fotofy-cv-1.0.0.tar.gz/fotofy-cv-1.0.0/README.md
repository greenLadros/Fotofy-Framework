# Fotofy-Framework

## What is Fotofy?
Fotofy is an open-source python framework bsed on opencv and numpy.
Fotofy is a strong frame-work for beginners and advenced,
Fotofy simplifies computer vision and making it accessible for everyone.

## How can i contribute?
You can create pull requests and add features if you want.
in the git-hub repo (https://github.com/greenLadros/Fotofy-Framework).

## How can i get started?
we got implementations and examples in the examples folder and
you can just look in it and try to use it.
